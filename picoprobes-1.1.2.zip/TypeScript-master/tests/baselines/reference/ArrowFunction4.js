//// [ArrowFunction4.ts]
var v = (a, b) => {
   
};

//// [ArrowFunction4.js]
var v = function (a, b) {
};
