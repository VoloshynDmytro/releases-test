//// [ClassDeclaration24.ts]
class any {
}

//// [ClassDeclaration24.js]
var any = (function () {
    function any() {
    }
    return any;
}());
