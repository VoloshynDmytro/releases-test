//// [ES5For-of1.ts]
for (var v of ['a', 'b', 'c']) {
    console.log(v);
}

//// [ES5For-of1.js]
for (var _i = 0, _a = ['a', 'b', 'c']; _i < _a.length; _i++) {
    var v = _a[_i];
    console.log(v);
}
//# sourceMappingURL=ES5For-of1.js.map