//// [ArrowFunctionExpression1.ts]
var v = (public x: string) => { };

//// [ArrowFunctionExpression1.js]
var v = function (x) { };
