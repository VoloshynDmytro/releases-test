//// [ES5SymbolType1.ts]
var s: symbol;
s.toString();

//// [ES5SymbolType1.js]
var s;
s.toString();
