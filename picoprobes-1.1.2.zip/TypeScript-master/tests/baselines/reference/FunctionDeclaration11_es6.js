//// [FunctionDeclaration11_es6.ts]
function * yield() {
}

//// [FunctionDeclaration11_es6.js]
function* yield() {
}
