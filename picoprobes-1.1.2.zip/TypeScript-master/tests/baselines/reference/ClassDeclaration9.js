//// [ClassDeclaration9.ts]
class C {
   foo();
}

//// [ClassDeclaration9.js]
var C = (function () {
    function C() {
    }
    return C;
}());
