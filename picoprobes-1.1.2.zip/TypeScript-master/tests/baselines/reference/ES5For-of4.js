//// [ES5For-of4.ts]
for (var v of [])
    var x = v;
var y = v;

//// [ES5For-of4.js]
for (var _i = 0, _a = []; _i < _a.length; _i++) {
    var v = _a[_i];
    var x = v;
}
var y = v;
