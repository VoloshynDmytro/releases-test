# The TypeScript Handbook

The contents of the TypeScript Handbook can be read from [its GitHub repository](https://github.com/Microsoft/TypeScript-Handbook).
Issues and pull requests should be directed there.