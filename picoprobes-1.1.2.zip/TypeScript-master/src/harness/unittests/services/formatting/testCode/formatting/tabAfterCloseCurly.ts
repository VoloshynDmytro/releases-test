module Tools {
    export enum NodeType {
        Error,
        Comment,
    }	
    export enum foob
    {
        Blah=1, Bleah=2
    }
}