module Foo {
    export module A.B.C { }
}