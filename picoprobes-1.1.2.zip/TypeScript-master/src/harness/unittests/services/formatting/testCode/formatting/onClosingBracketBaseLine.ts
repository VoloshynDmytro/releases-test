function f() {
    var x = 3;
    var z = 2;
    a = z++ - 2 * x;
    for (; ;) {
        a += (g + g) * a % t;
        b--;
    }

    switch (a) {
        case 1: {
            a++;
            b--;
            if (a === a)
                return;
            else {
                for (a in b)
                    if (a != a) {
                        for (a in b) {
                            a++;
                        }
                    }
            }
        }
        default:
            break;
    }
}
