$(document).ready(function() {
    alert('i am ready');
});