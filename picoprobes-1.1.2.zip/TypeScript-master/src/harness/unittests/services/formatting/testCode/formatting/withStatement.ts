with (foo.bar) 

   {

     }

with (bar.blah)
{
}
