<!-- BUGS: Please use this template. -->
<!-- QUESTIONS: This is not a general support forum! Ask Qs at http://stackoverflow.com/questions/tagged/typescript -->
<!-- SUGGESTIONS: See https://github.com/Microsoft/TypeScript-wiki/blob/master/Writing-Good-Design-Proposals.md -->

**TypeScript Version:**  2.2.1 / nightly (2.2.0-dev.201xxxxx)

**Code**

```ts
// A *self-contained* demonstration of the problem follows...

```

**Expected behavior:**

**Actual behavior:**
